export default {
  secret: '052212bb052172091d4af9a84a79e668',
  expiresIn: '7d',
};
