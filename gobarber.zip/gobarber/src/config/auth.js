export default {
  secret: '93d1578dcfccc51ca4cb0806608b5444',
  expireIn: '7d',
};
